#include <stdio.h>
#include <SDL.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <math.h>
#include <SDL.h>
#include <SDL2_gfxPrimitives.h>
#include <time.h>
#include <memory.h>
#include "structs.h"
#include "view.h"
#include "physics.h"
#include "logic.h"

void init_window()
{
    SDL_Init(SDL_INIT_VIDEO);
    window = SDL_CreateWindow("alterTank game", 20, 20,max_x, max_y, SDL_WINDOW_OPENGL);
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
}

void quit_window(char str0[],char str1[],char time[])
{
    SDL_SetRenderDrawColor(renderer,0,0,0, 255);
    SDL_RenderClear(renderer);
    stringRGBA(renderer, 7, 7, time,255,42,255,240);
    stringRGBA(renderer,max_x-150,max_y-14,str0,255,42,255,240);
    stringRGBA(renderer,10,max_y-14,str1,255,42,255,240);
    stringRGBA(renderer,max_x/2-40,max_y/2-10,"THE END",255,60,255,255);
    SDL_RenderPresent( renderer );
    SDL_Delay( 1500  );
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
}

void load(Map *map,char str0[],char str1[],char time[])
{
    int flag=0,loop=1;
    int r[3],g[3],b[3];
    while(loop)
    {
        for(int i=0; i<3; i++)
        {
            r[i]=0;
            g[i]=0;
            b[i]=0;
        }
        if(!flag)
        {
            b[1]=255;
            r[2]=255;
        }
        else if(flag==1)
        {
            g[0]=130;
            r[2]=255;
        }
        else
        {
            g[0]=130;
            b[1]=255;
        }
        SDL_Event event;
        SDL_SetRenderDrawColor(renderer,243, 68, 179, 255);
        SDL_RenderClear(renderer);
        thickLineRGBA(renderer,max_x  / 2-50, max_y  *2/6+7,max_x  / 2+50, max_y  *2/6-7,30,153, 255, 102,255);
        thickLineRGBA(renderer,max_x  / 2-50, max_y  *3/6+7,max_x  / 2+50, max_y  *3/6-7,30,102, 204, 255,255);
        thickLineRGBA(renderer,max_x  / 2-50, max_y  *4/6+7,max_x  / 2+50, max_y  *4/6-7,30,255, 255, 0, 255);
        stringRGBA(renderer, max_x  / 2-20, max_y   *2/6,"Game 1", r[0], g[0], b[0], 255);
        stringRGBA(renderer, max_x  / 2-20, max_y   *3/6,"Game 2", r[1], g[1],b[1], 255);
        stringRGBA(renderer, max_x  / 2-20,max_y   *4/6, "Game 3", r[2], g[2],b[2], 255);
        SDL_RenderPresent(renderer);
        while (SDL_PollEvent(&event))
        {
            if(event.type==SDL_QUIT || event.key.keysym.sym==SDLK_F4)
            {
                quit_window(str0,str1,time);
                loop=0;
            }
            if(event.type==SDL_KEYDOWN)
            {
                if (event.key.keysym.sym == SDLK_UP )
                {
                    if (!flag)
                        flag = 2;
                    else
                        flag--;
                }
                else if(event.key.keysym.sym ==SDLK_DOWN)
                {
                    if (flag==2)
                        flag=0;
                    else
                        flag ++;
                }
                else if (event.key.keysym.sym == SDLK_ESCAPE )
                {
                    flag=0;
                    loop=0;
                }
                else if(event.key.keysym.sym== SDLK_RETURN)
                {
                    loop=0;
                }
            }
        }
    }
    FILE *fp;
    if(flag==0) //load game 1
        fp = fopen("../src/data.txt", "r");
    else if(flag==1) //load game 2
        fp = fopen("../src/data1.txt", "r");
    else
        fp = fopen("../src/data2.txt", "r");

    fscanf(fp,"%d %d %d %d %d ",&num_walls,&max_x,&max_y,&index0,&index1);
    for(int i=0; i<num_walls; i++)
        fscanf(fp,"%d %d %d %d ",&(map->walls[i].x1),&(map->walls[i].y1),&(map->walls[i].x2),&(map->walls[i].y2));
    for(int t=0; t<2; t++)
    {
        fscanf(fp, "%d %d %lf %d %d %d %d ",&(map->tanks[t].x), &(map->tanks[t].y),
               &(map->tanks[t].angle), &(map->tanks[t].Powerup_m), &(map->tanks[t].Powerup_l), &(map->tanks[t].heart), &(map->tanks[t].score));
        for(int b=0; b<5; b++)
            fscanf(fp,"%d %d %lf %d %d %d %d ",&(map->tanks[t].bullets[b].x),&(map->tanks[t].bullets[b].y),
                   &(map->tanks[t].bullets[b].angle),&(map->tanks[t].bullets[b].shoot),&(map->tanks[t].bullets[b].time),
                   &(map->tanks[t].bullets[b].step_x),&(map->tanks[t].bullets[b].step_y));
    }
    fclose(fp);
}

void menu(int * condition,Map *map,Power* power,char str0[],char str1[],char time[])
{
    int flag=0,loop=1;
    int r[3],g[3],b[3];
    while(loop)
    {
        for(int i=0; i<3; i++)
        {
            r[i]=0;
            g[i]=0;
            b[i]=0;
        }
        if(!flag)
        {
            b[1]=255;
            r[2]=255;
        }
        else if(flag==1)
        {
            g[0]=130;
            r[2]=255;
        }
        else
        {
            g[0]=130;
            b[1]=255;
        }
        SDL_Event event;
        SDL_SetRenderDrawColor(renderer,40, 251, 244, 255);
        SDL_RenderClear(renderer);
        thickLineRGBA(renderer,max_x  / 2-60, max_y  *2/6+7,max_x  / 2+60, max_y  *2/6-7,30,153, 255, 102,255);
        thickLineRGBA(renderer,max_x  / 2-60, max_y  *3/6+7,max_x  / 2+60, max_y  *3/6-7,30,102, 204, 255,255);
        thickLineRGBA(renderer,max_x  / 2-60, max_y  *4/6+7,max_x  / 2+60, max_y  *4/6-7,30,255, 255, 0, 255);
        stringRGBA(renderer, max_x  / 2-45, max_y   *2/6,"  New Game", r[0], g[0], b[0], 255);
        stringRGBA(renderer, max_x  / 2-45, max_y   *3/6,"Loading Game", r[1], g[1],b[1], 255);
        stringRGBA(renderer, max_x  / 2-40,max_y   *4/6, "   Quit", r[2], g[2],b[2], 255);
        char key_1[5],key_2[5],key1[7],key2[7];
        sprintf(&key_1,"%c %c",up[0],shoot[0]);
        sprintf(&key_2,"%c %c",up[1],shoot[1]);
        sprintf(&key1,"%c %c %c",left[0],down[0],right[0]);
        sprintf(&key2,"%c %c %c",left[1],down[1],right[1]);
        stringRGBA(renderer,max_x-40,max_y-30,key_1,187, 14, 51,240);
        stringRGBA(renderer,40,max_y-30,key_2,187, 14, 51,240);
        stringRGBA(renderer,max_x-50,max_y-10,key1,187, 14, 51,240);
        stringRGBA(renderer,30,max_y-10,key2,187, 14, 51,240);
        SDL_RenderPresent(renderer);
        while (SDL_PollEvent(&event))
        {
            if(event.type==SDL_QUIT || event.key.keysym.sym==SDLK_F4)
            {
                quit_window(str0,str1,time);
                loop=0;
            }
            if(event.type==SDL_KEYDOWN)
            {
                if (event.key.keysym.sym == SDLK_UP )
                {
                    if (!flag)
                        flag = 2;
                    else
                        flag--;
                }
                else if(event.key.keysym.sym ==SDLK_DOWN)
                {
                    if (flag==2)
                        flag=0;
                    else
                        flag ++;
                }
                else if (event.key.keysym.sym == SDLK_ESCAPE )
                {
                    flag=3;
                    loop=0;
                }
                else if(event.key.keysym.sym== SDLK_RETURN)
                {
                    loop=0;
                }
            }
        }
    }
    if(!flag) //start
    {
        start(map,power);
        refresh(map);
        random_coordinates(map);
    }
    else if(flag==1) //load
        load(map,str0,str1,time);
    else if (flag==2) //exit
        quit_window(str0,str1,time);
    *condition=1;
}

void draw_tank(Tank tank,int t)
{
    filledCircleRGBA(renderer,tank.x,tank.y,rad_tank,72+t*107,18-18*t,72-13*t,255);
    filledEllipseRGBA(renderer,tank.x,tank.y,rand()%2+5,rand()%2+5,179-t*107,t*18,59+t*13, 250);
    filledEllipseRGBA(renderer,tank.x,tank.y,2,4,80,25,70,255);
    thickLineRGBA(renderer,tank.x,tank.y,tank.x+(step*4.5*(cos((tank.angle)*0.01745329251))),tank.y+step*4.5*(sin((tank.angle)*0.01745329251)),3,255,80,255,255);
}

void draw_bullet(Bullet bullet[])
{
    for(int i=0; i<5; i++)
    {
        if(bullet[i].shoot && bullet[i].time<FPS)
        {
            filledEllipseRGBA(renderer, bullet[i].x, bullet[i].y, radx_bullet, rady_bullet, 0, 0, 0, 255);
            filledEllipseRGBA(renderer,bullet[i].x,bullet[i].y,5,3,165+i*50,30+i*50,i*50,255);
            bullet[i].time++;
        }
        SDL_Delay(2);
    }
}

void handleEvents(Map* map,int *condition)
{
    SDL_Event event;
    while (SDL_PollEvent(&event))
    {
        if(event.type==SDL_QUIT || event.key.keysym.sym==SDLK_F4)
        {
            *condition = 0; //EXIT
            break;
        }
        else if( event.type == SDL_KEYDOWN)
        {
            if(event.key.keysym.sym == SDLK_s) //save game
            {
                Map temp;
                int Temp[5];
                FILE *fp1,*fp2;
                fp1 = fopen("../src/data1.txt", "r");
                fscanf(fp1,"%d %d %d %d %d ",&Temp[0],&Temp[1],&Temp[2],&Temp[3],&Temp[4]);
                for(int i=0; i<Temp[0]; i++)
                    fscanf(fp1,"%d %d %d %d ",&(temp.walls[i].x1),&(temp.walls[i].y1),&(temp.walls[i].x2),&(temp.walls[i].y2));
                for(int t=0; t<2; t++)
                {
                    fscanf(fp1, "%d %d %lf %d %d %d %d ",&(temp.tanks[t].x), &(temp.tanks[t].y),
                           &(temp.tanks[t].angle), &(temp.tanks[t].Powerup_m), &(temp.tanks[t].Powerup_l), &(temp.tanks[t].heart), &(temp.tanks[t].score));
                    for(int b=0; b<5; b++)
                        fscanf(fp1,"%d %d %lf %d %d %d %d ",&(temp.tanks[t].bullets[b].x),&(temp.tanks[t].bullets[b].y),
                               &(temp.tanks[t].bullets[b].angle),& (temp.tanks[t].bullets[b].shoot),&(temp.tanks[t].bullets[b].time),
                               &(temp.tanks[t].bullets[b].step_x),&(temp.tanks[t].bullets[b].step_y));
                }
                fclose(fp1);
                fp2 = fopen("../src/data2.txt", "w");
                fprintf(fp2,"%d %d %d %d %d ",Temp[0],Temp[1],Temp[2],Temp[3],Temp[4]);
                for(int i=0; i< Temp[0]; i++)
                    fprintf(fp2,"%d %d %d %d ",temp.walls[i].x1,temp.walls[i].y1,temp.walls[i].x2,temp.walls[i].y2);
                for(int t=0; t<2; t++)
                {
                    fprintf(fp2, "%d %d %lf %d %d %d %d ", temp.tanks[t].x, temp.tanks[t].y,
                            temp.tanks[t].angle, temp.tanks[t].Powerup_m,temp.tanks[t].Powerup_l, temp.tanks[t].heart, temp.tanks[t].score);
                    for(int b=0; b<5; b++)
                        fprintf(fp2,"%d %d %lf %d %d %d %d ",temp.tanks[t].bullets[b].x,temp.tanks[t].bullets[b].y,
                                temp.tanks[t].bullets[b].angle,temp.tanks[t].bullets[b].shoot,temp.tanks[t].bullets[b].time,
                                temp.tanks[t].bullets[b].step_x,temp.tanks[t].bullets[b].step_y);
                }
                fclose(fp2);

                fp1 = fopen("../src/data.txt", "r");
                fscanf(fp1,"%d %d %d %d %d ",&Temp[0],&Temp[1],&Temp[2],&Temp[3],&Temp[4]);
                for(int i=0; i<Temp[0]; i++)
                    fscanf(fp1,"%d %d %d %d ",&(temp.walls[i].x1),&(temp.walls[i].y1),&(temp.walls[i].x2),&(temp.walls[i].y2));
                for(int t=0; t<2; t++)
                {
                    fscanf(fp1, "%d %d %lf %d %d %d %d ",&(temp.tanks[t].x), &(temp.tanks[t].y),
                           &(temp.tanks[t].angle), &(temp.tanks[t].Powerup_m), &(temp.tanks[t].Powerup_l), &(temp.tanks[t].heart), &(temp.tanks[t].score));
                    for(int b=0; b<5; b++)
                        fscanf(fp1,"%d %d %lf %d %d %d %d ",&(temp.tanks[t].bullets[b].x),&(temp.tanks[t].bullets[b].y),
                               &(temp.tanks[t].bullets[b].angle),& (temp.tanks[t].bullets[b].shoot),&(temp.tanks[t].bullets[b].time),
                               &(temp.tanks[t].bullets[b].step_x),&(temp.tanks[t].bullets[b].step_y));
                }
                fclose(fp1);

                fp2 = fopen("../src/data1.txt", "w");
                fprintf(fp2,"%d %d %d %d %d ",Temp[0],Temp[1],Temp[2],Temp[3],Temp[4]);
                for(int i=0; i< Temp[0]; i++)
                    fprintf(fp2,"%d %d %d %d ",temp.walls[i].x1,temp.walls[i].y1,temp.walls[i].x2,temp.walls[i].y2);
                for(int t=0; t<2; t++)
                {
                    fprintf(fp2, "%d %d %lf %d %d %d %d ", temp.tanks[t].x, temp.tanks[t].y,
                            temp.tanks[t].angle, temp.tanks[t].Powerup_m,temp.tanks[t].Powerup_l, temp.tanks[t].heart, temp.tanks[t].score);
                    for(int b=0; b<5; b++)
                        fprintf(fp2,"%d %d %lf %d %d %d %d ",temp.tanks[t].bullets[b].x,temp.tanks[t].bullets[b].y,
                                temp.tanks[t].bullets[b].angle,temp.tanks[t].bullets[b].shoot,temp.tanks[t].bullets[b].time,
                                temp.tanks[t].bullets[b].step_x,temp.tanks[t].bullets[b].step_y);
                }
                fclose(fp2);

                fp1 = fopen("../src/data.txt", "w");
                fprintf(fp1,"%d %d %d %d %d ",num_walls,max_x, max_y,index0,index1);
                for(int i=0; i< num_walls; i++)
                    fprintf(fp1,"%d %d %d %d ",map->walls[i].x1,map->walls[i].y1,map->walls[i].x2,map->walls[i].y2);
                for(int t=0; t<2; t++)
                {
                    fprintf(fp1, "%d %d %lf %d %d %d %d ", map->tanks[t].x, map->tanks[t].y,
                            map->tanks[t].angle, map->tanks[t].Powerup_m,map->tanks[t].Powerup_l, map->tanks[t].heart, map->tanks[t].score);
                    for(int b=0; b<5; b++)
                        fprintf(fp1,"%d %d %lf %d %d %d %d ",map->tanks[t].bullets[b].x,map->tanks[t].bullets[b].y,
                                map->tanks[t].bullets[b].angle,map->tanks[t].bullets[b].shoot,map->tanks[t].bullets[b].time,
                                map->tanks[t].bullets[b].step_x,map->tanks[t].bullets[b].step_y);
                }
                fclose(fp1);
            }
            if (event.key.keysym.sym == SDLK_ESCAPE)
            {
                *condition = 4; // menu
                break;
            }
            else if (event.key.keysym.sym == shoot[0])
            {
                *condition = 2; //shelike tank[0]
                break;
            }
            if (event.key.keysym.sym == shoot[1])
            {
                *condition = 3; //shelike  tank[1]
                break;
            }
        }
        for(int t=0; t<2; t++)
        {
            int f= 0, qx = 0, qy = 0;
            for (int i = 0; i <num_walls; i++)
            {
                for (int j = -rad_tank; j <= rad_tank && !f; j++)
                {
                    if (((map->tanks[t].x + j) <= map->walls[i].x2) && ((map->tanks[t].x + j) >= map->walls[i].x1 )&&
                        ( (map->tanks[t].y + j) <= map->walls[i].y2)&& ((map->tanks[t].y + j) >=map->walls[i].y1) )
                    {
                        f++;
                        if (map->walls[i].x1 == map->walls[i].x2)
                            qx = j * step / rad_tank;
                        else
                            qy = j * step / rad_tank;
                    }
                }
            }
            if (f)
            {
                map->tanks[t].y -= qy;
                map->tanks[t].x -= qx;
            }
            turn_tank(event.key.keysym.sym, map->tanks,t);
            if (!f)
                move_tank(event.key.keysym.sym, map->tanks,t);
        }
    }
}

void draw_walls(Wall wall[])
{
    for(int i=0; i< num_walls ; i++)
        rectangleRGBA(renderer,wall[i].x1,wall[i].y1,wall[i].x2,wall[i].y2,25,255,255,255);
}

void draw_mine(Mine *mine,Map *map)
{
    if (mine->time < FPS && mine->active)
    {
        if( mine->x-25<=map->tanks[mine->enemy].x &&  map->tanks[mine->enemy].x<=mine->x+25 &&
            mine->y-25<=map->tanks[mine->enemy].y &&  map->tanks[mine->enemy].y<=mine->y+25 )
        {
            mine->active=false;
            filledCircleRGBA(renderer, mine->x, mine->y, 10, 0, 0, 0, 255);
            map->tanks[mine->enemy].heart--;
            map->tanks[not(mine->enemy)].score++;
            SDL_Delay(110);
            filledCircleRGBA(renderer, mine->x, mine->y, 250, 0, 0, 0, 255);
            map->tanks[mine->enemy].x=rand()%(max_x)+5;
            map->tanks[mine->enemy].y=rand()%(max_y)+5;
        }
        stringRGBA(renderer,max_x/3,max_y-15,"mine is active!",150,0,100,255);
        mine->time++;
        if(mine->time>=FPS)
            mine->active=false;
    }
}

void draw_laser(Laser* laser,Map *map)
{
    laser->x1=map->tanks[laser->tank].x+(25*(cos((map->tanks[laser->tank].angle)*0.01745329251)));
    laser->y1=map->tanks[laser->tank].y+(25*(sin((map->tanks[laser->tank].angle)*0.01745329251)));
    laser->angle=map->tanks[laser->tank].angle;
    laser->x2 =laser->x1;
    laser->y2 =laser->y1;

    int i=1000;
    if ( laser->active && laser->time<FPS)
    {
        while(i)
        {
            laser->x2 += 7 * (cos((laser->angle) * 0.01745329251));
            laser->y2 += 7 * (sin((laser->angle) * 0.01745329251));
            i--;
            if( laser->x2 <= map->tanks[not(laser->tank)].x + rad_tank && laser->x2 >= map->tanks[not(laser->tank)].x -rad_tank &&
                laser->y2 <= map->tanks[not(laser->tank)].y + rad_tank && laser->y2 >= map->tanks[not(laser->tank)].y -rad_tank )
            {
                laser->x2 = map->tanks[not(laser->tank)].x;
                laser->y2 = map->tanks[not(laser->tank)].y;
                if(laser->shoot==1)
                {
                    map->tanks[laser->tank].Powerup_l=0;
                    laser->active=false;
                    laser->shoot=-1;
                    map->tanks[laser->tank].score++;
                    map->tanks[not(laser->tank)].heart--;
                    map->tanks[not(laser->tank)].x=rand()%(max_x)+5;
                    map->tanks[not(laser->tank)].y=rand()%(max_y)+5;
                }
                break;
            }
        }
        laser->time++;
        if(laser->time>=FPS)
            laser->active=false;
        lineRGBA(renderer,laser->x1,laser->y1,laser->x2,laser->y2,255,23,0,255);
    }
}

void draw_powerup(Power *power)
{
    if(power->time<FPS)
    {
        filledEllipseRGBA(renderer,power->x,power->y,14,7,rand()%255,rand()%255,rand()%255,255);
        power->time++;
    }
}