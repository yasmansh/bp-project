#include <stdlib.h>
#include <time.h>
#include <SDL_events.h>
#include <SDL2_gfxPrimitives.h>
#include <stdio.h>
#include "logic.h"
#include "structs.h"

int max(int x,int y)
{
    if(x>y)
        return x;
    return y;
}

int not(int x)
{
    if(x)
        return 0;
    return 1;
}

void Max_Score()
{
    int loop = 1, key;
    max_score=0;
    char maxscore[10];
    while (loop)
    {
        SDL_Event event;
        SDL_SetRenderDrawColor(renderer, 255, 42, 255, 255);
        SDL_RenderClear(renderer);
        sprintf(&maxscore,"%d",max_score);
        stringRGBA(renderer, max_x / 2 -20, max_y /2+25,maxscore,  255,255, 255, 255);
        stringRGBA(renderer, max_x / 2 -100, max_y /2, "Enter the winning score",  255,255, 255, 255);
        SDL_RenderPresent(renderer);
        while (SDL_PollEvent(&event) && loop)
        {
            if(event.type==SDL_QUIT || event.key.keysym.sym==SDLK_F4)
                loop=0;
            if (event.type == SDL_KEYDOWN)
            {
                key = event.key.keysym.sym;
                if(key==SDLK_RETURN )
                    loop = 0;
                else
                {
                    max_score *=10;
                    if(key>=48 && key<=57)
                        max_score +=key-48;
                    else if(key<=1073741921 && key>=1073741912)
                        max_score +=key-1073741912;
                }
            }
        }
    }
}


void select_key()
{
    int flag = 0, loop = 1, key;
    int g[10];
    while (loop)
    {
        for (int i = 0; i < 10; i++)
            g[i] = 42;
        g[flag]=255;
        SDL_Event event;
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);
        stringRGBA(renderer, max_x / 2 -38, max_y * 2 / 12, " Up tank1",  255, g[0], 255, 255);
        stringRGBA(renderer, max_x / 2 -40, max_y * 3 / 12, "Down tank1", 255, g[1], 255, 255);
        stringRGBA(renderer, max_x / 2 -40, max_y * 4 / 12, "Right tank1",255, g[2], 255, 255);
        stringRGBA(renderer, max_x / 2 -37, max_y * 5 / 12, "Left tank1", 255, g[3], 255, 255);
        stringRGBA(renderer, max_x / 2 -40, max_y * 6 / 12, "Shoot tank1",255, g[4], 255, 255);
        stringRGBA(renderer, max_x / 2 -38, max_y * 7 / 12, " Up tank2",  255, g[5], 255, 255);
        stringRGBA(renderer, max_x / 2 -40, max_y * 8 / 12, "Down tank2", 255, g[6], 255, 255);
        stringRGBA(renderer, max_x / 2 -40, max_y * 9 / 12, "Right tank2",255, g[7], 255, 255);
        stringRGBA(renderer, max_x / 2 -37, max_y * 10/ 12, "Left tank2", 255, g[8], 255, 255);
        stringRGBA(renderer, max_x / 2 -40, max_y * 11/ 12, "Shoot tank2",255, g[9], 255, 255);

        SDL_RenderPresent(renderer);
        while (SDL_PollEvent(&event) && loop)
        {
            if(event.type==SDL_QUIT || event.key.keysym.sym==SDLK_F4)
            {
                loop=0;
                break;
            }
            if (event.type == SDL_KEYDOWN)
            {
                key = event.key.keysym.sym;
                if (!flag)
                    up[0] = key;
                else if (flag == 1)
                    down[0] = key;
                else if (flag == 2)
                    right[0] = key;
                else if (flag == 3)
                    left[0] = key;
                else if (flag == 4)
                    shoot[0] = key;
                else if (flag == 5)
                    up[1] = key;
                else if (flag == 6)
                    down[1] = key;
                else if (flag == 7)
                    right[1] = key;
                else if (flag == 8)
                    left[1] = key;
                else if (flag == 9)
                {
                    shoot[1] = key;
                    loop = 0;
                }
                flag++;
            }
        }
    }
}

void random_coordinates( Map * map)
{
    srand(time(0));
    int check=1;
    while(check)
    {
        check=0;
        for(int t=0; t<2; t++)
        {

            map->tanks[t].x =rand()%(max_x)+5;
            map->tanks[t].y =rand()%(max_y)+5;
        }
        for(int t=0; t<2 && !check ; t++) //check kardNe inke tanka tu divRa nabashan!
        {
            for (int j = 0; j < num_walls; j++)
            {
                if (map->walls[j].x1 - rad_tank <= map->tanks[t].x && map->tanks[t].x <= map->walls[j].x2 + rad_tank &&
                    map->walls[j].y1 - rad_tank <= map->tanks[t].y && map->tanks[t].y <= map->walls[j].y2 + rad_tank)
                {
                    check = 1;
                    break;
                }
            }
        }
    }
}

void start(Map * map, Power * power)
{
    power->time=0;
    power->mine.active=false;

    power->laser.shoot=-1;
    power->laser.time=0;
    power->laser.active=false;

    for(int t=0; t<2; t++)
    {
        for (int i = 0; i < n_bullet; i++)
        {
            map->tanks[t].Powerup_m=0;
            map->tanks[t].Powerup_l=0;
            map->tanks[t].heart=10;
            map->tanks[t].score=0;
            map->tanks[t].angle = rand()%360;
        }
    }
}

void refresh(Map* map)
{
    index0=0;
    index1=0;
    for(int t=0; t<2; t++)
    {
        for(int i=0; i<n_bullet; i++)
        {
            map->tanks[t].bullets[i].shoot=false;
            map->tanks[t].bullets[i].step_x=5;
            map->tanks[t].bullets[i].step_y=5;
        }
    }
}