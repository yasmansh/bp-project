#ifndef STRUCT_H
#define STRUCT_H

#include <SDL_video.h>
#include <SDL_render.h>
#include <stdbool.h>

extern SDL_Window *window;
extern SDL_Renderer *renderer;

int const rad_tank, radx_bullet, rady_bullet,n_bullet, step, FPS;

int  condition, cx_wall,cy_wall,num_walls, max_x,max_y,index0,index1,max_score,up[2],down[2],right[2],left[2],shoot[2];

typedef struct
{
    int x;
    int y;
    int time;
    int enemy;
    bool active;
} Mine;

typedef struct
{
    int x1;
    int y1;
    int x2;
    int y2;
    double angle;
    int tank;
    int shoot;
    int time;
    bool active;
} Laser;

typedef struct
{
    int x;
    int y;
    int time;
    Mine mine;
    Laser laser;
} Power;

typedef struct
{
    int x, y;
    double angle;
    bool shoot;
    int time;
    int step_x;
    int step_y;
} Bullet;

typedef struct
{
    int x, y;
    double angle;
    Bullet bullets[5];
    int heart;
    int Powerup_m;
    int Powerup_l;
    int score;
} Tank;

typedef struct
{
    int x1;
    int y1;
    int x2;
    int y2;
} Wall;

typedef struct
{
    Tank tanks[2];
    Wall walls[36];
} Map;

#endif
