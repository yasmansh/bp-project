#ifndef LOGIC_H
#define LOGIC_H
#include "structs.h"

int max(int x,int y);

int not(int x);

void Max_Score();

void select_key();

void random_coordinates( Map * map);

void start(Map * map, Power * power);

void refresh(Map* map);

#endif