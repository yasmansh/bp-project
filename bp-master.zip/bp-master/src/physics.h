#ifndef PHYSICS_H
#define PHYSICS_H

void move_tank (SDL_Keycode key, Tank tank[],int t);

void turn_tank(SDL_Keycode key,Tank tank[],int t);

void shetab(Bullet * bullet);

void move_bullet(Bullet bullet[]);

void fire(Tank * tank,int index);

void attack(Map *map);

void BulletReflection(Map *map,int t,int k);

void Power_up(Map *map,Power *power);

#endif