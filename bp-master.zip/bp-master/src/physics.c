#include <stdio.h>
#include <SDL.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <math.h>
#include <SDL.h>
#include <SDL2_gfxPrimitives.h>
#include <time.h>
#include "structs.h"
#include "view.h"
#include "physics.h"
#include "logic.h"

void move_tank (SDL_Keycode key, Tank tank[],int t)
{
    if(key== up[t])
    {
        tank[t].y += step * (sin((tank[t].angle) * 0.01745329251));
        tank[t].x += step * (cos((tank[t].angle) * 0.01745329251));
    }
    if(key== down[t])
    {
        tank[t].y -= step * (sin((tank[t].angle) * 0.01745329251));
        tank[t].x -= step * (cos((tank[t].angle) * 0.01745329251));
    }
}

void turn_tank(SDL_Keycode key,Tank tank[],int t)
{
    if(key== right[t])
        tank[t].angle += step;
    if(key==  left[t])
        tank[t].angle -= step;
}

void shetab(Bullet * bullet)
{
    if(bullet->time%50==0)
    {
        if (bullet->step_y>0)
            bullet->step_y++;
        else
            bullet->step_y--;
        if (bullet->step_x>0)
            bullet->step_x++;
        else
            bullet->step_x--;
    }
}

void move_bullet(Bullet bullet[])
{
    for(int i=0; i<5; i++)
    {
        if(bullet[i].shoot && bullet[i].time<FPS)
        {
            shetab(&(bullet[i]));
            bullet[i].x+=bullet[i].step_x*cos(bullet[i].angle* 0.01745329251);
            bullet[i].y+=bullet[i].step_y*sin(bullet[i].angle* 0.01745329251);
        }
    }
}

void fire(Tank * tank,int index)
{
    tank->bullets[index].x=tank->x+(25*(cos((tank->angle)*0.01745329251)));
    tank->bullets[index].y=tank->y+(25*(sin((tank->angle)*0.01745329251)));
    tank->bullets[index].angle=tank->angle;
    tank->bullets[index].shoot=true;
    tank->bullets[index].time=0;
}

void attack(Map *map)
{
    for(int k=0; k<2; k++)
    {
        for(int t=0; t<2; t++)
        {
            for(int i=0; i<5 ; i++)
            {
                if(map->tanks[k].bullets[i].shoot && map->tanks[k].bullets[i].time<FPS)
                {
                    if (((map->tanks[t].x - rad_tank) <= (map->tanks[k].bullets[i].x + radx_bullet)) &&
                        ((map->tanks[k].bullets[i].x - radx_bullet) <= (map->tanks[t].x + rad_tank)) &&
                        ((map->tanks[t].y - rad_tank) <= (map->tanks[k].bullets[i].y + rady_bullet)) &&
                        ((map->tanks[k].bullets[i].y - rady_bullet) <= (map->tanks[t].y + rad_tank)))
                    {
                        random_coordinates(map);
                        map->tanks[t].heart--;
                        map->tanks[not(t)].score++;
                    }
                }
            }
        }
    }
}

void BulletReflection(Map *map,int t,int k)
{
    if( map->tanks[t].bullets[k].shoot &&  map->tanks[t].bullets[k].time <FPS)
    {
        for (int i = 0; i < num_walls; i++)
        {

            if (map->tanks[t].bullets[k].x <= (map->walls[i].x2 + radx_bullet) &&
                map->tanks[t].bullets[k].x >= (map->walls[i].x1 - radx_bullet) &&
                map->tanks[t].bullets[k].y <= (map->walls[i].y2 + rady_bullet) &&
                map->tanks[t].bullets[k].y >= (map->walls[i].y1 - rady_bullet))
            {
                if (map->walls[i].x1 == map->walls[i].x2) //divare Amudi
                {
                    map->tanks[t].bullets[k].step_x *= -1;
                }
                else   //divare ofoqi
                {
                    map->tanks[t].bullets[k].step_y *= -1;
                }
                break;
            }
        }
    }
}

void Power_up(Map *map,Power *power)
{
    for (int t = 0; t < 2 && power->time < FPS; t++)
    {
        if (map->tanks[t].x - rad_tank <= power->x && power->x <= map->tanks[t].x + rad_tank &&
            map->tanks[t].y - rad_tank <= power->y && power->y <= map->tanks[t].y + rad_tank)
        {
            power->time = 300;
            if (t)
                map->tanks[1].Powerup_m = true;
            else
                map->tanks[0].Powerup_m = true;
        }
    }
}
