#ifndef VIEW_H
#define VIEW_H

void init_window();

void quit_window(char str0[],char str1[],char time[]);

void load(Map *map,char str0[],char str1[],char time[]);

void menu(int * condition,Map *map,Power * power,char str0[],char str1[],char time[]);

void draw_tank(Tank tank,int t);

void draw_bullet(Bullet bullet[]);

void handleEvents(Map* map,int *condition);

void draw_walls(Wall wall[]);

void draw_mine(Mine *mine,Map *map);

void draw_laser(Laser* laser,Map *map);

void draw_powerup(Power *power);

#endif