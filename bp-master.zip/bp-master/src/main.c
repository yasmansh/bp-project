#include <stdio.h>
#include <SDL.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <math.h>
#include <SDL.h>
#include <SDL2_gfxPrimitives.h>
#include <time.h>
#include "structs.h"
#include "view.h"
#include "physics.h"
#include "logic.h"
#ifdef main
#undef main
#endif

void read_map_file(Map *map,int *num_walls,int* max_x,int* max_y)
{
    FILE * fp;
    int random=rand()%3;
    if(random==0)
    {
        fp=fopen("../src/map1.txt","r");
        cx_wall=70;
        cy_wall=70;
    }
    else if(random==1)
    {
        fp=fopen("../src/map2.txt","r");
        cx_wall=70;
        cy_wall=90;
    }
    else if(random==2)
    {
        fp=fopen("../src/map3.txt","r");
        cx_wall=105;
        cy_wall=90;
    }
    fscanf(fp, "%d",num_walls);
    int x1, y1, x2, y2;
    for (int i = 0; i < *num_walls; i++) //630 630
    {
        fscanf(fp, "%d%d%d%d", &x1, &y1, &x2, &y2);
        map->walls[i].x1 =  x1*cx_wall ;
        map->walls[i].y1 =  y1*cy_wall ;
        map->walls[i].x2 =  x2*cx_wall ;
        map->walls[i].y2 =  y2*cy_wall ;
        *max_x = max(x2*cx_wall, *max_x);
        *max_y = max(y2*cy_wall, *max_y);
    }
    fclose(fp);
}

SDL_Window* window;
SDL_Renderer* renderer;

int main(int argc,char* argv[])
{
    int begining_of_time = SDL_GetTicks(),check=1,count=0;
    char Time[50], str0[20],str1[20],heart0[20],heart1[20];
    srand(time(0));
    Map map;
    Power power;

    start(&map,&power);
    refresh(&map);
    read_map_file(&map,&num_walls,&max_x,&max_y);
    random_coordinates(&map);
    init_window();
    Max_Score();
    select_key();
    menu(&condition,&map,&power,str0,str1,Time); // menu ye avale bazi

    while (map.tanks[0].heart * map.tanks[1].heart)
    {
        int start_ticks = SDL_GetTicks();
        char heart_0[]="           ",heart_1[]="           ";
        count++;
        handleEvents(&map,&condition);
        if(!condition || map.tanks[0].score==max_score || map.tanks[1].score==max_score)
            break;
        SDL_SetRenderDrawColor(renderer,255,72,110,250);
        SDL_RenderClear(renderer);
        if(condition==4) //menu
            menu(&condition,&map,&power,str0,str1,Time);
        if(condition==2 || condition==3) // shelike tank[0] ya tank[1]
        {
            if (map.tanks[condition - 2].Powerup_m) //mine
            {
                map.tanks[condition - 2].Powerup_m = 0;
                map.tanks[condition - 2].Powerup_l = 1;
                power.mine.active = true;
                power.mine.time=0;
                power.mine.enemy = not(condition - 2);
                power.mine.x = map.tanks[condition - 2].x;
                power.mine.y = map.tanks[condition - 2].y;
            }
            else if(map.tanks[condition - 2].Powerup_l) //laser
            {
                power.laser.active=true;
                power.laser.shoot++;
                power.laser.time=0;
                power.laser.tank= condition-2;
            }
            else // tire aadi.
            {
                if (condition == 2)
                {
                    if (index0 < 5)
                        fire(&map.tanks[0], index0);
                    index0++;
                }
                else
                {
                    if (index1 < 5)
                        fire(&map.tanks[1], index1);
                    index1++;
                }
            }
            condition = 1;
        }
        draw_walls(map.walls);
        for(int t=0; t<2; t++)
        {
            for(int k=0; k<5; k++)
                BulletReflection(&map, t,k);

            draw_bullet(map.tanks[t].bullets);
            move_bullet(map.tanks[t].bullets);
            draw_tank(map.tanks[t],t);
        }
        if(map.tanks[0].bullets[4].shoot * map.tanks[1].bullets[4].shoot)
            refresh(&map);

        if(!(count%720)) //power up
        {
            power.time=0;
            power.x=rand()%(max_x);
            power.y=rand()%(max_y);
        }
        draw_powerup(& power);
        Power_up(&map,&power);
        draw_mine(&(power.mine),&map);
        draw_laser(&(power.laser),&map);

        attack(&map);

        for(int i=0,j=0; i<map.tanks[0].heart ||j<map.tanks[1].heart; i++ && j++)
        {
            if(i<map.tanks[0].heart )
            {
                if(i%4==1 || i%4==3)
                    heart_0[i]=510;
                else if (i%4)
                    heart_0[i]=479;
                else
                    heart_0[i]=476;
            }
            if(j<map.tanks[1].heart )
            {
                if(j%4==1 || j%4==3)
                    heart_1[j]=510;
                else if(j%4)
                    heart_1[j]=479;
                else
                    heart_1[j]=476;
            }
        }
        sprintf(& Time, "elapsed time: %d ms  :)", start_ticks - begining_of_time);
        sprintf(&str0,"Tank Score1 : %d",map.tanks[0].score);
        sprintf(&str1,"Tank Score2 : %d",map.tanks[1].score);
        sprintf(&heart0,"Heart tank1: %d",map.tanks[0].heart);
        sprintf(&heart1,"Heart tank2: %d",map.tanks[1].heart);

        stringRGBA(renderer, 7, 7, Time,150,0,100,255);
        stringRGBA(renderer,max_x-145,max_y-44,heart_0,150,0,100,255);
        stringRGBA(renderer,15,max_y-44,heart_1,150,0,100,255);
        stringRGBA(renderer,max_x-145,max_y-25,heart0,150,0,100,255);
        stringRGBA(renderer,15,max_y-25,heart1,150,0,100,255);
        stringRGBA(renderer,max_x-150,max_y-14,str0,150,0,100,255);
        stringRGBA(renderer,10,max_y-14,str1,150,0,100,255);

        SDL_RenderPresent(renderer);
    }
    quit_window(str0,str1,Time);
}